import java.util.ArrayList;
public class Warehouse{

    private String serial; //id of each warehouse;
    private ArrayList<Product> products; // Create an arraylist named products;

    public String getSerial(){
        return serial;
    }// Get id of the warehouse, while there is no necessity to reset it.

    public ArrayList<Product> getProducts(){
        return products;
    } // Get elements inside the list;

    public Warehouse(String serial){
        this.serial = serial;
        this.products = new ArrayList<>();
    } // Create a specific list for each warehouse;

    public void listProducts(){
        for(Product product : products){
            System.out.println(product);
        }
    } // display all products;

    public void addProduct(Product product){
        products.add(product);
    } // add product into the list;

    public Product findProduct(int id){
        for(Product product : products){
            if(product.getId() == id){
                return product;
            }
        }
        return null; //A must for not finding the target product.
    } //Find products by its owned id;

    public boolean removeProduct(int id){
        Product temp = findProduct(id);
        if(temp != null){
            products.remove(temp);
            return true;
        }
        return false;
    } //remove some unwanted products;

    public boolean updateLeftNum(int id0, int num0){
        Product product = findProduct(id0);
        if(product == null){
            return false;
        }
        int updatedLeftNum = product.getLeftNum() + num0;
        if(updatedLeftNum < 0){
            return false;
        }
        product.setLeftNum(updatedLeftNum);
        return true;
    } //To keep the left number of each product updated;

    public ArrayList<Product> findBrand(String keyword) {
        ArrayList<Product> result = new ArrayList<>();
        String lower = keyword.toLowerCase();
        for (Product product : products) {
            if (product.getBrand().toLowerCase().contains(lower)) {
                result.add(product);
            }
        }
        return result;
    } //Find wanted products by searching their brand, and display the result by a new list.
      //Considering convenience, I used "toLowerCase" to transform capital letter, that's user-friendly;


    public ArrayList<Product> findCategory(String keyword) {
        ArrayList<Product> result = new ArrayList<>();
        String lower = keyword.toLowerCase();

        for (Product product : products) {
            if (product.getCategory().toLowerCase().contains(lower)) {
                result.add(product);
            }
        }
        return result;
    } //Same route as the upper one, this is a method finding products by searching the category, like I get a Nike Dri-Fit by typing in "T-shirt" or "Vest";
      //And this also applied "toLowerCase" to ensure users' convenience;
}