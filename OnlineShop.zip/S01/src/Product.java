public class Product {

    private int id; //id of each product;
    private String name; //name of each product;
    private String category; //category of each product;
    private String brand; //brand of each product;
    private String color; //color of each product;
    private String size; //size of each product;
    private double price; //price of each price;
    private int leftNum; // leftNum of each leftNum;

    public Product(int id, String name, String category, String brand, String color, String size, double price, int leftNum){
        this.id = id;
        this.name = name;
        this.category = category;
        this.brand = brand;
        this.color = color;
        this.size = size;
        this.price = price;
        this.leftNum = leftNum;
    } // This method is to define every product, which involves these aspects;

    public int getId(){
        return id;
    }
    public String getName(){
        return name;
    }
    public String getCategory(){
        return category;
    }
    public String getBrand(){
        return brand;
    }
    public String getColor(){return color;}
    public String getSize(){
        return size;
    }
    public double getPrice(){
        return price;
    }
    public int getLeftNum(){
        return leftNum;
    }

    public void setId(int id){
        this.id = id;
    } // This can be removed.
    public void setName(String name){
        this.name = name;
    }
    public void setCategory(String category){
        this.category = category;
    }
    public void setBrand(String brand){
        this.brand = brand;
    }
    public void setColor(String color){
        this.color = color;
    }
    public void setSize(String size){
        this.size = size;
    }
    public void setPrice(double price){
        this.price = price;
    }
    public void setLeftNum(int leftNum){
        this.leftNum = leftNum;
    } //These getters and setters can be used to get or set the value of these variables later;

    public String toString(){
        return id + "/" + name + "/" + category + "/" +brand + "/" + color + "/" +size + "/" + price + "/" +leftNum;
    } //Rewrite this method.
}
