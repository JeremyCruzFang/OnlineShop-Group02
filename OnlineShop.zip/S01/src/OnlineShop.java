import java.util.ArrayList;
public class OnlineShop{

    private ArrayList<Warehouse> warehouses; //Arraylist "warehouses";
    private ArrayList<Order> orders; //Arraylist "orders";
    private int laterOrderId = 1; // Initialize the orderId in the whole procedure;

    public OnlineShop(){
        warehouses = new ArrayList<>();
        orders = new ArrayList<>();
    }

    public void addWarehouse(Warehouse WH){
        warehouses.add(WH);
    } //Function: add warehouse(WH1,WH2,WH3);

    public void listProducts(){
        for(Warehouse WH: warehouses){
            WH.listProducts();
        }
    } // Function: list all the products;

    public Product findProduct(int id){
        for(Warehouse WH: warehouses){
            Product product = WH.findProduct(id);
            if(product != null){
                return product;
            }
        }
        return null;
    } //Function: find product by its id;

    public ArrayList<Product> findBrand(String brand){
        ArrayList<Product> result = new ArrayList<>();
        for(Warehouse WH: warehouses){
            for(Product product: WH.findBrand(brand)){
                result.add(product);
            }
        }
        return result;
    } // Function: find product by its brand;

    public ArrayList<Product> findCategory(String category){
        ArrayList<Product> result = new ArrayList<>();
        for(Warehouse WH: warehouses){
            for(Product product: WH.findCategory(category)){
                result.add(product);
            }
        }
        return result;
    } //Function: find product by its category;

    public int deal(int id, int quantity){
        for(Warehouse WH: warehouses){
            if(WH.updateLeftNum(id, -quantity)){
                Order order = new Order(laterOrderId, id, quantity,WH.getSerial());
                orders.add(order);
                int nowOrderId = laterOrderId;
                laterOrderId++;
                return nowOrderId;
            }
        }
        return -1;
    } //Function: purchase a product after having seen its id by the function above;

    private Order findOrder(int orderId){
        for(Order order: orders){
            if(order.getOrderId() == orderId){
                return order;
            }
        }
        return null;
    } //Function: find each order's info(written in order.java)by its orderId;

    public boolean refund(int orderId){
        Order order = findOrder(orderId);
        if(order == null){
            System.out.println("Wrong id has been input!");
            return false;
        }
        if(order.isSituation()){
            System.out.println("This order has already been refunded successfully before!");
            return false;
        }
        for(Warehouse WH: warehouses){
            if(WH.updateLeftNum(order.getId(), order.getQuantity())){
                order.setSituation(true);
                System.out.println("Your order is now refunded successfully!");
                return true;
            }
        }
        return false;
    } //Function: refund(different situations: wrong id; refunded or not)
      //Quantity of each order is recorded in orders, so the leftNum can be revised correctly.
}