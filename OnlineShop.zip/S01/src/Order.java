public class Order{
    private int orderId;
    private int id;
    private int quantity;
    private String warehouseSerial; //Yes, I have found that I didn't apply this variable to the method which identifies the warehouse when refunding!!!
    private boolean situation;// For this one, "true" means the product in the order has been refunded before or just now; "false" means the order goes as it was originally;

    public Order(int orderId, int id, int quantity, String warehouseSerial){
        this.orderId = orderId;
        this.id = id;
        this.quantity = quantity;
        this.situation = false;
        this.warehouseSerial = warehouseSerial;
    }

    public int getOrderId(){
        return orderId;
    }
    public int getId(){
        return id;
    }
    public int getQuantity(){
        return quantity;
    }
    public String getWarehouseSerial() {
        return warehouseSerial;
    } //This can be removed. If I apply this, I wouldn't have to build a range cycle to find the corresponding warehouse.
    public boolean isSituation(){
        return situation;
    }
    public void setSituation(boolean situation){
        this.situation = situation;
    }
    public String toString(){
        return orderId + "  " + id + "  " + quantity + "  " + situation;
    }
}