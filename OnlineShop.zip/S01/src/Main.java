import java.util.ArrayList;
import java.util.Scanner; //This file faces users.

public class Main{
    private static void menu(){
        System.out.println("Welcome to our onlineShop");
        System.out.println("Press -1- to see the products we have here;");
        System.out.println("Press -2- to find your loved brand;");
        System.out.println("Press -3- to find your wanted category;");
        System.out.println("Press -4- to find your target accurately by id searching;");
        System.out.println("Press -5- Refund your pre-deal if needed");
        System.out.println("Press -0- to log out");
    } //It's a menu, functions are listed here.
    public static void main(String[] args){

        OnlineShop os = new OnlineShop();
        Warehouse WH1 = new Warehouse("WH1");
        Warehouse WH2 = new Warehouse("WH2");
        Warehouse WH3 = new Warehouse("WH3");

        WH1.addProduct(new Product(101, "Nike Zoom Kobe 6 Protro \"Total Orange\"",
                "shoes", "Nike", "Orange", "8.5", 249, 50));
        WH1.addProduct(new Product(102, "Nike Dri-Fit all black",
                "T-shirt", "Nike", "Black", "L", 39, 20));
        WH2.addProduct(new Product(201, "iPhone 17 Pro Max",
                "Mobile", "Apple", "Silver", "2TB", 1299, 2));
        WH2.addProduct(new Product(202, "iPhone 17 Pro Max",
                "Mobile", "Apple", "Orange", "512G", 1199, 8));
        WH3.addProduct(new Product(301, "Apple Gift Card",
                "GiftCard", "Apple", "Null", "once", 100, 100));
        os.addWarehouse(WH1);
        os.addWarehouse(WH2);
        os.addWarehouse(WH3);

        Scanner input = new Scanner(System.in); //Spy the info users type in;
        boolean toDeal = true; //Start the shopping trip!
        while(toDeal){
            menu();
            System.out.println("Please enter the corresponding number to get relevant information"); //Instruction;
            String cn = input.nextLine();
            //capital letter will be transformed into lowercase as I did in Warehouse.java, so it's user-friendly;
            switch(cn){
                case "1":
                    System.out.println("Here are all our selling products!");
                    os.listProducts();
                    break;
                    // display all the products;
                case "2":
                    System.out.println("Type in the brand of the product you want!");
                    String brand = input.nextLine();
                    ArrayList<Product> inBrand = os.findBrand(brand);
                    if(inBrand.isEmpty()){
                        System.out.println("Sorry, this brand is not available here!");
                    }
                    else{
                        System.out.println("results:");
                        for(Product product: inBrand){
                            System.out.println(product);
                        }
                    }
                    break;
                    // find products by brand;
                case "3":
                    System.out.println("Type in the category of the product you want!");
                    String category = input.nextLine();
                    ArrayList<Product> inCategory = os.findCategory(category);
                    if(inCategory.isEmpty()){
                        System.out.println("Sorry, this category is not available here!");
                    }
                    else{
                        System.out.println("results:");
                        for(Product product: inCategory){
                            System.out.println(product);
                        }
                    }
                    break;
                    // find products by category;
                case "4":
                    System.out.println("Complete your purchase now----");
                    System.out.println("Notice!!!: id and quantity are both number form.");
                    System.out.println("Way to go: type in id and press enter, then type in quantity and press enter again.");
                    int id = input.nextInt();
                    input.nextLine();
                    int quantity = input.nextInt();
                    input.nextLine();
                    int orderId = os.deal(id, quantity);
                    if(orderId == -1) {
                        System.out.println("The deal failed: No enough products OR this one doesn't exist");
                    }
                    else{
                        System.out.println("Make it! Your OrderId is :" + orderId);
                    }
                    break;
                    // purchase procedure: different situations: leftNum is not enough; id is not correct;
                case "5":
                    System.out.println("Type in the orderId of the deal you want to refund");
                    System.out.println("Type in the orderId(number form) and press enter.");
                    int orderId0 = input.nextInt();
                    input.nextLine();
                    boolean situation0 = os.refund(orderId0);
                    if(situation0){
                        System.out.println("Your deal is now refunded successfully!");
                    }
                    else{
                        System.out.println("Refund failed, please make sure whether the id was true or the deal had been refunded or not!");
                    }
                    break;
                    // refund procedure;
                case "0":
                    toDeal = false;
                    System.out.println("Leave now? See you in your next shopping trip! If you have any recommendation, please contact in abc1519176175@gmail.com");
                    break;
                default:
                    System.out.println("Wrong operation , check the menu to move on--");
                // Opt out;
            }

        }
        input.close(); // close the shop view;
    }
}